package com.kaewkung.myoverlay

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.LinearGradient
import android.graphics.Paint
import android.graphics.RectF
import android.graphics.Shader
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.widget.LinearLayout
import android.widget.TextView
import android.widget.Toast
import kotlin.math.min

const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

/** พาเลตต์สี My Overlay: ม่วงเข้ม + ม่วงสว่าง + ฟ้าไซยาน */
object C {
    val BG = Color.parseColor("#0E0B1A")
    val CARD = Color.parseColor("#1A1530")
    val CARD2 = Color.parseColor("#2A2250")
    val ACCENT = Color.parseColor("#8B5CF6")
    val CYAN = Color.parseColor("#22D3EE")
    val TEXT = Color.parseColor("#F3F0FF")
    val SUB = Color.parseColor("#A39BC8")
    val OK = Color.parseColor("#34D399")
    val WARN = Color.parseColor("#FBBF24")
    val DANGER = Color.parseColor("#F43F5E")
}

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()

fun Context.toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

fun roundBg(color: Int, radius: Float, stroke: Int = 0, strokeW: Int = 0): GradientDrawable =
    GradientDrawable().apply {
        setColor(color)
        cornerRadius = radius
        if (strokeW > 0) setStroke(strokeW, stroke)
    }

fun Context.tv(t: String, sp: Float, color: Int, bold: Boolean = false): TextView =
    TextView(this).apply {
        text = t
        textSize = sp
        setTextColor(color)
        if (bold) typeface = Typeface.DEFAULT_BOLD
    }

fun Context.pill(t: String, bg: Int, fg: Int = C.TEXT, onClick: () -> Unit): TextView =
    TextView(this).apply {
        text = t
        textSize = 14f
        setTextColor(fg)
        typeface = Typeface.DEFAULT_BOLD
        gravity = Gravity.CENTER
        setPadding(dp(16), dp(11), dp(16), dp(11))
        background = roundBg(bg, dp(14).toFloat())
        setOnClickListener { onClick() }
    }

fun Context.card(): LinearLayout = LinearLayout(this).apply {
    orientation = LinearLayout.VERTICAL
    background = roundBg(C.CARD, dp(20).toFloat())
    setPadding(dp(16), dp(14), dp(16), dp(14))
}

fun Context.lp(w: Int = MATCH, h: Int = WRAP, topDp: Int = 0, weight: Float = 0f): LinearLayout.LayoutParams =
    LinearLayout.LayoutParams(w, h, weight).apply { topMargin = dp(topDp) }

/** รูปโปรไฟล์: วงกลมไล่สี + การ์ดซ้อนกัน 3 ใบ (สื่อถึง overlay) */
class AvatarView(c: Context) : View(c) {
    private val p = Paint(Paint.ANTI_ALIAS_FLAG)

    override fun onDraw(canvas: Canvas) {
        val w = width.toFloat()
        val h = height.toFloat()
        p.shader = LinearGradient(0f, 0f, w, h, C.ACCENT, C.CYAN, Shader.TileMode.CLAMP)
        canvas.drawCircle(w / 2, h / 2, min(w, h) / 2, p)
        p.shader = null
        fun rect(ox: Float, oy: Float, col: Int) {
            p.color = col
            canvas.drawRoundRect(
                RectF(w * 0.22f + ox, h * 0.26f + oy, w * 0.62f + ox, h * 0.54f + oy),
                w * 0.07f, w * 0.07f, p
            )
        }
        rect(0f, 0f, Color.argb(110, 255, 255, 255))
        rect(w * 0.08f, h * 0.10f, Color.argb(170, 255, 255, 255))
        rect(w * 0.16f, h * 0.20f, Color.WHITE)
    }
}
